var express = require('express');
var mongoose = require('mongoose');
var jwt = require('jsonwebtoken');
var aes = require('aes256');
var User = require('./models/User');
var app = express();

const dbConnectionString = 'mongodb://localhost:27017/UsersCollection';
const port = process.env.PORT || 4000;
const key = 'Design Lab';

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
 
// app.use((req, res, next) => {
//   console.log('*')
//   res.header({"Access-Control-Allow-Origin": "*"})
// }) 
mongoose
  .connect(dbConnectionString, {
      useNewUrlParser: true, 
      useUnifiedTopology: true
    })
  .then(() => {
    console.log("Database is connected");
  })
  .catch(err => {
    console.log("Error is ", err.message);
  });

app.get('/',(req,res)=>{
   res.status(200).send(`Hi Welcome to the Login and Signup API`);
});

app.post('/signup', async (req, res) => {
    console.log('hitting signup!')
    var {email, password, secQuestion, secAnswer} = req.body;
    if(!email || !password || !secQuestion || !secAnswer){
        return res.status(401).send('Req Body must contain fields: name, password and phone!')
    }
    password = aes.encrypt(key, password);
    var newUser = new User({
      email,
      password,
      secQuestion,
      secAnswer
    });
    const authToken = jwt.sign({
      exp: Math.floor(Date.now() / 1000) + (60 * 60),
      data: email
    }, 'design lab');

    await newUser
      .save()
      .then(() => {
        return res.status(200).send({email, password: '*********', secQuestion, secAnswer, token: authToken});
      })
      .catch(err => {
        console.log("Error is ", err.message);
        return res.status(400).send('Bad Request!')
      });
})

app.post('/login', async (req,res)=>{
  var {email, password} = req.body;
  if(!email || !password){
    return res.status(401).send('Req Body must contain fields: name, & password!')
  }

  await User.findOne({ email })
    .then(profile => {
      if (!profile) {
        res.status(404).send("User does not exist");
      } else {        
        if(password === aes.decrypt(key, profile.password)){
          const authToken = jwt.sign({
            exp: Math.floor(Date.now() / 1000) + (60 * 60),
            data: email
          }, 'design lab');

          return res.status(200).send({email, password: '*********', secQuestion: profile.secQuestion, secAnswer: profile.secAnswer,imageLink: profile.imageLink, token: authToken});
        } else {
          return res.status(401).send('User Unauthorized Access!');
        }
      }
    })
    .catch(err => {
      console.log("Error is ", err.message);
    });
});

app.post('/valid-email', async (req, res) => {
  try{
    // const token = req.header('Authorization').replace('Bearer ', '');
    const {email} = req.body;
    if(!email){
      return res.status(400).send('Req Body must contain fields: email')
    }
    // const decoded = jwt.verify(token, 'design lab')

    // if(decoded.data !== email) {
    //   throw new Error('Token not matching!');
    // }

    const user = await User.findOne({
        email
    })

    if(user && user.email){
      // console.log('valid-email', user)
      return res.status(200).send({valid: true, secQuestion: user.secQuestion});
    } else {
      return res.status(200).send({valid: false})
    }

  } catch (e) {
    console.log(e);
    return res.status(401).send({error: 'Unable to authenticate, perhaps auth token missing or corrupted?'})
  }
});

app.patch('/pass', async (req,res)=>{    
  try {
    // const token = req.header('Authorization').replace('Bearer ', '');
    const {email, secAnswer, newPass} = req.body;
    if(!email || !secAnswer || !newPass){
      return res.status(400).send('Req Body must contain fields: email, security answer & new password!')
    }
    // const decoded = jwt.verify(token, 'design lab')

    const user = await User.findOne({
        email,
    })

    if (!user) {
        throw new Error('No user') 
    }
    console.log(user)
    if( user.secAnswer === secAnswer){
      user.password = aes.encrypt(key, newPass);
      return await user
      .save()
      .then(() => {
        return res.status(200).send({message: 'Password Changed Successfully!'});
      })
    } else {
      return res.status(401).send({error: 'Password did not match!'})
    }
  } catch (e) {
    console.log(e)
    return res.status(401).send({error: 'Some error Occured!'})
  }
})

app.get('/profile', async (req, res)=>{
  try {
    const token = req.header('Authorization').replace('Bearer ', '');
    const {data} = jwt.verify(token, 'design lab');

    const user = await User.findOne({
      email: data
    });

    if(!user){
      throw new Error('No user');
    }
    const {email, password, secQuestion, secAnswer, imageLink} = user;
    return res.status(200).send({email, password: aes.decrypt(key, password), secQuestion, secAnswer, imageLink});
  } catch(e) {
    console.log(e);
    return res.status(400).send({error: 'Unable to authenticate, perhaps auth token missing?'})
  }
});


app.patch('/profile', async (req,res)=>{
  try {
    const token = req.header('Authorization').replace('Bearer ', '');
    const {email, password, secAnswer, secQuestion, imageLink} = req.body;
    // console.log(email, password, secAnswer, secQuestion, imageLink)
    if(!email){
      return res.status(400).send('Req Body must contain fields: email!')
    }
    const decoded = jwt.verify(token, 'design lab')

    const user = await User.findOne({
        email
    })

    if (!user || email !== decoded.data) {
        throw new Error('No user');
    }

    
    user.password = aes.encrypt(key, password);
    user.secQuestion = secQuestion;
    user.seqAnswer = secAnswer;
    user.imageLink = imageLink;

    await user
    .save()
    .then(() => {
      return res.status(200).send({email, password, secQuestion, secAnswer, imageLink, token});
    })
    
  } catch (e) {
    console.log(e)
    return res.status(401).send({error: 'Unable to authenticate, perhaps auth token missing?'})
  }
})

app.put('/users', (req, res)=>{
  try {
    const token = req.header('Authorization').replace('Bearer ', '');
    var {email, users} = req.body;
    // console.log(email, password, secAnswer, secQuestion, imageLink)
    if(!email){
      return res.status(400).send('Req Body must contain fields: email!')
    }
    const {data} = jwt.verify(token, 'design lab');
    console.log(email, data)
    if(email !== data){
      throw new Error('User Not Matched!');
    }
    users.forEach( user => {user.addedBy = email; user.password = aes.encrypt(key, user.password)})
    // console.log("USERS:", users);

    return User.insertMany(users)
    .then(docs =>{
      // console.log("USERS Inserted", docs)
      return res.status(200).send({message: 'Bulk User Inserted!'})
    })
    .catch(e => { 
      console.log(e); 
      res.status(500).send({message: 'Bulk User Insertion Failed!'})
    });

  } catch (e) {
    console.log(e)
    return res.status(401).send({error: 'Unable to authenticate, perhaps auth token missing?'})
  }
})

app.get('/users/:email', (req, res)=>{
  try {
    const token = req.header('Authorization').replace('Bearer ', '');
    const {email} = req.params;
    // console.log(email, password, secAnswer, secQuestion, imageLink)
    if(!email){
      return res.status(400).send('Req URL must contain fields: email!')
    }
    const {data} = jwt.verify(token, 'design lab');
    // console.log(email, data)
    if(email !== data){
      throw new Error('User Not Matched!');
    }

    return User.find({addedBy: email})
    .then(docs =>{
      // console.log("USERS Inserted", docs)
      if(docs.length>0) return res.status(200).send(docs.map(({email, password, secQuestion, secAnswer, addedBy}) => ({email, password, secQuestion, secAnswer, addedBy})));
      return res.status(200).send([{email: '', password: '', secQuestion: '', secAnswer: '', addedBy: ''}])
    })
    .catch(e => { 
      console.log(e); 
      res.status(500).send({message: 'Bulk User Insertion Failed!'})
    });
    

  } catch (e) {
    console.log(e)
    return res.status(401).send({error: 'Unable to authenticate, perhaps auth token missing?'})
  }
})
app.listen(port,()=>{
   console.log(`Server is listening on port ${port}`)
});