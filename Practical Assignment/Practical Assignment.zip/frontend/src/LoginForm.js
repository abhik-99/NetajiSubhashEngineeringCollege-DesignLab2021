import React, {useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import { Button, Dialog, DialogTitle, DialogContent, DialogActions, Typography, InputLabel } from '@material-ui/core';

import CircularProgress from '@material-ui/core/CircularProgress';
import NavigateNextIcon from '@material-ui/icons/NavigateNext';
import NavigateBeforeIcon from '@material-ui/icons/NavigateBefore';

import bottom from './bottom.svg';
import { Redirect, withRouter } from 'react-router-dom';

const useStyles = makeStyles((theme) => ({
    formRoot:{
        height: '250px',
        paddingTop: theme.spacing(3),
    }
}));

const ForgotPasswordDialog = (props) => {
    const {open, onClose} = props;
    //to receive email and check if its valid
    const [validEmail, setvalidEmail] = useState(false)
    const [email, setEmail] = useState('');

    //show the security question, receive the answer and check its validity
    const [secQues, setsecQues] = useState('');
    const [secAns, setsecAns] = useState('');
    const [validAns, setvalidAns] = useState(false);

    //to receive new password
    const [newPassword, setNewPassword] = useState('');

    //to check false email
    const [falseEmail, setfalseEmail] = useState(false)
    const [falseAns, setfalseAnswer] = useState(false);

    const handleEmailSubmit = async (e) => {
        e.preventDefault();
        console.log('The Email Is:-', email);
        const response = await fetch('/valid-email',{
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            // 'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: JSON.stringify({email})
        })
        // console.log("Response", response)
        const responseBody = await response.json()
        if(responseBody.valid){
            setsecQues(responseBody.secQuestion);
            setvalidEmail(true);
        } else {
            setfalseEmail(true);
        }
    };

    const handleSecurityQuestionSubmit = (e) => {
        e.preventDefault();
        console.log('The Answer is:-', secAns);

        setvalidAns(true);
    }

    const handleNewPasswordSubmit = async (e) => {
        e.preventDefault();
        console.log('Password:', newPassword)
        const response = await fetch('/pass', {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            // 'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: JSON.stringify({email, secAnswer: secAns, newPass: newPassword})
        })
        if(response.status !== 200){
            const resBody = await response.json();
            if(resBody.error === 'Password did not match!');
            console.log("Response not 200!", resBody)
            setfalseAnswer(true);
        } else if(response.status === 200){

            setvalidAns(false);
            setvalidEmail(false);
            onClose();
        }
    }

    return (
        <Dialog open={open} onClose={onClose}>
            <DialogTitle>Forgot Password?</DialogTitle>
            {
                !validEmail && !validAns &&
                <form onSubmit={handleEmailSubmit}>
                    <DialogContent>
                        <Box paddingBottom={2}>
                            <InputLabel>
                                <b>Enter your Email:</b>
                            </InputLabel>
                        </Box>
                        <Box paddingBottom={5}>
                            <TextField 
                            id='email' 
                            label='Email' 
                            variant='outlined'
                            color='secondary'
                            type='email'
                            fullWidth
                            onChange={(e) => setEmail(e.target.value)}
                            required
                            />
                        </Box>
                    </DialogContent>
                    <DialogActions>
                        {
                            falseEmail &&
                            <Typography variant='caption' color='secondary'>Email does not exist!</Typography>
                        }
                        <Button variant='outlined' color='secondary' type='submit' endIcon={<NavigateNextIcon/>}>Next</Button>
                    </DialogActions>
                </form>
            }
            {
                validEmail && !validAns &&
                <form onSubmit={handleSecurityQuestionSubmit}>
                    <DialogContent>
                        <Box paddingBottom={2}>
                            <InputLabel >
                                <b>Answer Your Security Question:</b>
                            </InputLabel>
                        </Box>
                        <Box paddingBottom={5}>
                            <TextField 
                            id='securityAnswer' 
                            label={secQues} 
                            variant='outlined'
                            color='secondary'
                            type='text'
                            fullWidth
                            defaultValue={secAns.length === 0 ? secQues : secAns}
                            onChange={(e) => setsecAns(e.target.value)}
                            required
                            />
                        </Box>
                    </DialogContent>
                    <DialogActions>
                        <Button variant='outlined' color='secondary' type='submit' endIcon={<NavigateNextIcon/>}>Next</Button>
                    </DialogActions>                 
                </form>
            }
            {
                validEmail && validAns &&
                <form onSubmit={handleNewPasswordSubmit}>
                    <DialogContent>
                        <Box paddingBottom={2}>
                            <InputLabel>
                                <b>Enter your new password:</b>
                            </InputLabel>
                        </Box>              
                        <Box paddingBottom={5}>
                            {
                                falseAns && 
                                <Typography variant='caption' color='secondary'>Wrong Answer to Security Question</Typography>
                            }
                            <TextField 
                            id='newPassword' 
                            label='Your New Password' 
                            variant='outlined'
                            color='secondary'
                            type='text'
                            fullWidth
                            onChange={(e) => setNewPassword(e.target.value)}
                            required
                            />
                        </Box>
                    </DialogContent>
                    <DialogActions>
                        <Button color='secondary' startIcon={<NavigateBeforeIcon/>} onClick={()=>{setvalidAns(false)}}>Back</Button>
                        <Button variant='contained' color='secondary' type='submit'>Change Password!</Button>
                    </DialogActions>
                </form>
            }

        </Dialog>
    );
};

const LoginForm = (props) => {
    const {history} = props;
    
    const classes = useStyles();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [submitting, setSubmitting] = useState(false)
    const [fpDialog, setfpDialog] = useState(false)

    const [wrongPassword, setwrongPassword] = useState(false)

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        const response = await fetch('/login', {
            method: "POST", 
            headers: {
                'Content-Type': 'application/json'
            // 'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: JSON.stringify({
                email,
                password
            })
        })
        
        setSubmitting(false);
        if(response.status === 200){
                    
            history.push({
                pathname:'/profile',
                state: await response.json()
            });
        } else {
            setwrongPassword(true)
        }
        
    }

    const handleFPDialogClose = () => {
        setfpDialog(false);
    };
    const handleFPDialogOpen = () => {
        setfpDialog(true);
    };

    return (
        <div className={classes.formRoot} align='center'>
            {
                submitting &&
                <Box align='center'>
                    <CircularProgress/>
                </Box>
            }
            {
                !submitting &&
                <>
                <form onSubmit={handleSubmit}>
                    {
                        wrongPassword &&
                        <Typography variant='caption' color='secondary'>Wrong Credentials!</Typography>
                    }
                    <Box paddingBottom={4}>
                        <TextField 
                        id='email' 
                        label='Email' 
                        variant='outlined'
                        color='primary'
                        type='email'
                        fullWidth
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        />
                    </Box>

                    <Box paddingBottom={3}>
                        <TextField 
                        id='password' 
                        label='Password' 
                        variant='outlined'
                        color='primary'
                        type='password'
                        fullWidth
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        />
                        <Button style={{textTransform:'none'}} onClick={handleFPDialogOpen}><Typography variant='caption'>Forgot Password...</Typography></Button>
                    </Box>

                    <Button variant='contained' color='primary' fullWidth type='submit' disabled={submitting}>Login</Button>
                    
                </form>
                <ForgotPasswordDialog open={fpDialog} onClose={handleFPDialogClose}/>

                <Box marginTop={2}>
                    <img src={bottom} alt='Palm Trees' height='30px'/>   
                </Box>
                </>
            }
        </div>
    )
}

export default withRouter(LoginForm);
