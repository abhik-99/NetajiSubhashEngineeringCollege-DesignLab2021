import React from 'react';
import './App.css';
import { Route, Switch } from 'react-router';
import {makeStyles} from '@material-ui/core/styles';
import {CssBaseline} from '@material-ui/core';
import Signup from './Signup';
import Profile from './Profile';

const useStyles = makeStyles((theme) => ({
  root: {
    minHeight: '100vh',
    backgroundImage: `url(https://images.unsplash.com/photo-1625120742520-3f085b6894ba?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1352&q=80)`,
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  }
}))

function App() {
  const classes = useStyles();
  // const [image, setImage ] = useState("");
  // const [ url, setUrl ] = useState("");
  // const uploadImage = () => {
  //   const data = new FormData()
  //   data.append("file", image)
  //   data.append("upload_preset", "tutorial")
  //   data.append("cloud_name","breellz")
  //   fetch("  https://api.cloudinary.com/v1_1/dutyboundidiot/image/upload",{
  //     method:"post",
  //     body: data
  //   })
  //   .then(resp => resp.json())
  //   .then(data => {
  //     setUrl(data.url)
  //   })
  //   .catch(err => console.log(err))
  // }
  return (
    <div className={classes.root}>
      <CssBaseline/>
      <Switch>
        <Route path='/profile' exact>
          <Profile/>
        </Route>
        <Route path='/' exact>
          <Signup/>
        </Route>
      </Switch>
    {/* <div>
    <input type="file" onChange= {(e)=> setImage(e.target.files[0])}></input>
    <button onClick={uploadImage}>Upload</button>
    </div>
    <div>
    <h1>Uploaded image will be displayed here</h1>
    <img src={url}/>
    </div> */}
    </div>
  )
}

export default App;
