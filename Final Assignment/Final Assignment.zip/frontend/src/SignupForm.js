import React, {useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import { Button, Divider, Typography } from '@material-ui/core';

import CircularProgress from '@material-ui/core/CircularProgress';
import bottom from './bottom.svg';
import { Redirect, withRouter } from 'react-router-dom';

const useStyles = makeStyles((theme) => ({
    formRoot:{
        height: '250px',
        paddingTop: theme.spacing(3),
        alignItems: 'center',
    }
}));

const SignupForm = (props) => {
    const classes = useStyles();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [secQuestion, setsecQues] = useState('');
    const [secAnswer, setsecAns] = useState('');
    
    const [submitting, setSubmitting] = useState(false);

    const [dU, setdU] = useState(false)

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        const response = await fetch('/signup',{
            method: 'POST', // *GET, POST, PUT, DELETE, etc.
            headers: {
                'Content-Type': 'application/json'
            // 'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: JSON.stringify({
                email,
                password,
                secQuestion,
                secAnswer
            })
        })
        if(response.status !== 200){
            setdU(true)
        } else {

            const {token} = await response.json()
            setSubmitting(false);
            console.log("Token at signup", token)
            props.history.push({
                pathname: '/profile',
                state:{ email, password, secQuestion, secAnswer, token}
            })
        }
    }
    return (
        <div className={classes.formRoot} align='center'>
            {
                submitting &&
                <Box align='center'>
                    <CircularProgress/>
                </Box>
            }
            {
                !submitting &&
                <>
                <form onSubmit={handleSubmit}>
                    <Box paddingBottom={5}>
                        <TextField 
                        id='email' 
                        label='Email' 
                        variant='outlined'
                        color='primary'
                        type='email'
                        fullWidth
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        />
                    </Box>

                    <Box paddingBottom={2}>
                        <TextField 
                        id='password' 
                        label='Password' 
                        variant='outlined'
                        color='primary'
                        type='password'
                        fullWidth
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        />
                    </Box>

                    <Divider/>
                    <Box paddingBottom={2} paddingTop={2}>
                        <TextField 
                        id='question' 
                        label='Security Question' 
                        variant='outlined'
                        color='primary'
                        type='text'
                        onChange={(e) => setsecQues(e.target.value)}
                        required
                        />
                    </Box>
                    <Box paddingBottom={5}>
                        <TextField 
                        id='answer' 
                        label='Security Answer' 
                        variant='outlined'
                        color='primary'
                        type='text'
                        onChange={(e) => setsecAns(e.target.value)}
                        required
                        />
                    </Box>
                    {
                        dU &&
                        <Typography variant='caption' color='secondary'>User already exists! Please login.</Typography>
                    }

                    <Button variant='contained' color='primary' fullWidth type='submit' disabled={submitting}>Sign Up!</Button>
                </form>
                <Box marginTop={3}>
                    <img src={bottom} alt='Palm Trees' height='30px'/>   
                </Box>
                </>
            }
        </div>
    )
}

export default withRouter(SignupForm);
