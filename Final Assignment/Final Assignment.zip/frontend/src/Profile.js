import React, {useState, useEffect, useRef} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { 
    Button, 
    Avatar, 
    Typography, 
    Box,
    Dialog,
    DialogTitle,
    DialogActions,
    DialogContent,
    TextField
} from '@material-ui/core';

import { Redirect, withRouter } from 'react-router-dom';

import CreateTwoToneIcon from '@material-ui/icons/CreateTwoTone';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import ListAltTwoToneIcon from '@material-ui/icons/ListAltTwoTone';
import GetAppTwoToneIcon from '@material-ui/icons/GetAppTwoTone';

import readXlsxFile from 'read-excel-file';
import exportFromJSON from 'export-from-json';

const useStyles = makeStyles((theme) => ({
    profile: {
        width: '380px',
        height: '500px',
        backgroundColor: theme.palette.background.paper,
        borderRadius: '30px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center'
    },
    avatar: {
        width: theme.spacing(20),
        height: theme.spacing(20)
    }
}));


function ChangeDialog(props) {
    const classes = useStyles();
    const { onClose, selectedValue, open, token, history } = props;
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [imageLink, setImageLink] = useState('');
    const [secQuestion, setSecQuestion] = useState('');
    const [secAnswer, setSecAnswer] = useState('');
    const [errorOccured, setError] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    
    useEffect( () => {
        async function fetchData(){
            const response = await fetch('/profile', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                // 'Content-Type': 'application/x-www-form-urlencoded',
                },
            }) 
            if(response.status !== 200){
                history.push({pathname: '/'})
            }else{
                const {email, password, imageLink, secQuestion, secAnswer} = await response.json();
                setEmail(email);
                setPassword(password);
                setImageLink(imageLink);
                setSecQuestion(secQuestion);
                setSecAnswer(secAnswer);
            }
        }
        fetchData();
    }, [token, history, setEmail, setPassword, setImageLink, setSecQuestion, setSecAnswer]);


    const handleClose = () => {
      onClose(selectedValue);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        const response = await fetch('/profile', {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            // 'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: JSON.stringify({email, password, secAnswer, secQuestion, imageLink})
        })
        if(response.status === 200){
            history.push({
                pathname: '/profile',
                state: await response.json()
            })
            handleClose();
        }else{
            setError(true);
        }
        setSubmitting(false);
    }
  
    return (
      <Dialog onClose={handleClose} aria-labelledby="change-dialog-title" open={open}>
        <DialogTitle id="change-dialog-title"><b>Change Profile Information</b></DialogTitle>
        <form onSubmit={handleSubmit}>
            <DialogContent style={{display: 'flex', flexDirection:'column'}}>
                
                    <Box paddingBottom={2}>
                        <TextField 
                        id='email' 
                        label='Email' 
                        variant='outlined'
                        color='primary'
                        type='email'
                        fullWidth
                        disabled
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        />
                    </Box>

                    <Box paddingBottom={2}>
                        <TextField 
                        id='image' 
                        label='Link to New Image (JPG)' 
                        variant='outlined'
                        color='primary'
                        type='text'
                        fullWidth
                        defaultValue={imageLink}
                        onChange={(e) => setImageLink(e.target.value)}
                        required
                        />
                    </Box>

                    <Box paddingBottom={2}>
                        <TextField 
                        id='password' 
                        label='Password' 
                        variant='outlined'
                        color='primary'
                        type='text'
                        defaultValue={password}
                        fullWidth
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        />
                    </Box>
                    <Box paddingBottom={2}>
                        <TextField 
                        id='secQues' 
                        label='Security Question' 
                        variant='outlined'
                        color='primary'
                        type='text'
                        defaultValue={secQuestion}
                        fullWidth
                        onChange={(e) => setSecQuestion(e.target.value)}
                        required
                        />
                    </Box>
                    <Box paddingBottom={2}>
                        <TextField 
                        id='secAnswer' 
                        label='Security Answer' 
                        variant='outlined'
                        color='primary'
                        type='text'
                        defaultValue={secAnswer}
                        fullWidth
                        onChange={(e) => setSecAnswer(e.target.value)}
                        required
                        />
                    </Box>
                    
                
            </DialogContent>
            <DialogActions>
                    {
                        errorOccured &&
                        <Typography color='secondary' variant='caption'>Some Error Occured!</Typography>
                    }
                <Button variant='outlined' color='primary' type='submit' disabled={submitting}><b>Make Changes</b></Button>
            </DialogActions>
        </form>
      </Dialog>
    );
  }

const Profile = (props) => {
    // console.log("Props in Profile", props)
    const uploadInputRef = useRef(null);

    const classes = useStyles();

    const [open, setOpen] = useState(false);
    const [bulkUploaded, setbulkUploaded] = useState(false);
    

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };
    const handleLogout = () => {
        props.history.push({pathname: '/'})
    }
    const handleExcelUpload = (e, email, token) =>{
        const map = {
            "Email": "email",
            "Password": "password",
            "Security Question": "secQuestion",
            "Security Answer": "secAnswer"
        }
        readXlsxFile(e.target.files[0], {map}).then(async ({rows}) => {
            // `rows` is an array of rows
            // each row being an array of cells.
            console.log("The rows are", rows)
            const response = await fetch('/users',{
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                // 'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: JSON.stringify({email, users: rows})
            })

            setbulkUploaded(true)
            e.target.value = null
          })
    };

    const handleExcelDownload = async (email, token) =>{

        const response = await fetch(`/users/${email}`, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            // 'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        const users = await response.json()
        exportFromJSON({
            data: users, 
            fileName: `Users Added By ${email}`, 
            exportType: 'xls', 
            fields: {
                "email": "Email",
                "password": "Password",
                "secQuestion": "Security Question",
                "secAnswer": "Security Answer"
            }
        });
    }

    if(!props.location.state){
        return <Redirect to='/'/>
    } else {
        const {email, secQuestion, secAnswer, imageLink, token} = props.location.state;
        const falsePass = props.location.state.password;
        return (
            <div className={classes.profile}>
                {
                    imageLink &&
                    <Avatar src={imageLink} className={classes.avatar} />
                }
                <Box paddingTop={4}>
                    <Typography><b>Email:</b> {email}</Typography>
                </Box>
                <Box paddingTop={2}>
                    <Typography><b>Password:</b> {falsePass}</Typography>
                </Box>
                <Box paddingTop={2}>
                    <Typography><b>Security Question:</b> {secQuestion}</Typography>
                </Box>
                <Box paddingTop={2}>
                    <Typography><b>Security Answer:</b> {secAnswer}</Typography>
                </Box>
                <Box paddingTop={2} >
                    <Button startIcon={<CreateTwoToneIcon/>} variant='contained' color='primary' onClick={handleClickOpen}>Edit Profile</Button>                    
                </Box>
                <Box paddingTop={1}>
                    <Button startIcon={<ExitToAppIcon/>} variant='contained' color='secondary' onClick={handleLogout}>Logout</Button>
                </Box>
                <ChangeDialog open={open} onClose={handleClose} token={token} history={props.history}/>
            </div>
        )
    }

    
}

export default withRouter(Profile)
