var mongoose = require('mongoose');
const UserSchema = mongoose.Schema({
    email:{
        type: String,
        require: true,
        unique: true
    },
    password:{
        type: String,
        require: true
    },
    secQuestion:{
        type: String,
        require: true
    },
    secAnswer:{
        type: String,
        require:true
    },
    imageLink:{
        type: String,
    },
    addedBy:{
        type: String
    }
});
module.exports = User = mongoose.model('UserSchema',UserSchema);
